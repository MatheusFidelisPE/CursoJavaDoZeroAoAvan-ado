# Atividades Semana 1 IP2
## Atividade para construção de classes, instanciar objetos e trabalhar com git

## Atividade 1:
Tutorial git (Main)
## Atividade 2: 
Tutorial git (Remote)
## Atividade 3: 
Criação das classes Produto, Estoque e TesteEstoqueMain. Instanciar objetos em TesteEstoqueMain
## Atividade 4:
Java.time
## Atividade 5: 
 Implementação de 4 classes de acordo com um diagrama UML

